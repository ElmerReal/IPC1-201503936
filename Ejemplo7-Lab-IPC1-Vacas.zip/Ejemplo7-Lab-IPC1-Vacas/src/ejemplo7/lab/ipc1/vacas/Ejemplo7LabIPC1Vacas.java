/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo7.lab.ipc1.vacas;

import tablero.tablero;

/**
 *
 * @author elmer
 */
public class Ejemplo7LabIPC1Vacas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        tablero t = new tablero("Mi primer juego");
        t.show();
    }
    
}
